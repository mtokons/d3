Example Angular App
===================

# Preparation
You have to install Nodejs (https://nodejs.org/en/) and
Angular Cli (https://cli.angular.io/).
Then install the dependencies for the express server and the angular app.
Run `npm install` in the directories '/code' and '/code/client/todo-app'.

# Angular Development Server
If you regularly change things in the angular app, I would recommend using
the angular development server. Everytime you make a change and save the file,
the server automatically updates the website.
To start this development server run the `ng serve` command
in the /code/client/todo-app directory.
You can see the side at http://localhost:4200/

Hint: If you use this development server you only can look at the angular app.
All functionalities in the app, that depent on a connection/requests to the
express server(with the REST-API) will not work.

# Build the Angular App
For the express server to be able to deliver the app, the app has to be build first.
Run `ng build` in the /code/client/todo-app directory.

# Start the express server
To <b>only</b> start the server run the command `npm start` in the '/code' dir.
You can see the side at http://localhost:3000/.

# Build the Angular App and start the server using one command
Run `npm run rocket` in the '/code' directory.
You can see the side at http://localhost:3000/

# For more information
See the following sides:
- https://cli.angular.io/
- https://angular.io/docs
- https://material.angular.io/ (only if you use angular material)