/**
 * Example Todo Server App
 * 
 * @author len_wei
 * @version 20180705
 */
'use strict';

const express = require('express')
const path = require('path')
const bodyParser = require('body-parser')

const appRoot = require('app-root-path');
const router = require(appRoot +'/server/routes/api')
const mongo_router = require(appRoot +'/server/routes/mongo')

const app = express()
app.use(bodyParser.json())
app.use('/api', router)
app.use('/mongo', mongo_router)

//static files
app.use(express.static(path.join(__dirname, 'client/todo-app/dist/')));

app.get('/', (req, res) => {
  res.sendFile('index.html')
  res.end()
})

const port = 3000
app.listen(port, () => {
  console.log('Listening at port: ' + port)
});
