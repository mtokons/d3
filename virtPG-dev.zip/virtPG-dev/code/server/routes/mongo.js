/**
 * 
 * @author len_wei
 * @version 20180705
 */
const express = require('express')
const router = express.Router()

const appRoot = require('app-root-path');
const Descriptor = require(appRoot + '/server/db/data/descriptor/descriptor.js');

router.get('/getDescriptorList', (req, res) => {
    console.log('GET::/getDescriptorList')
    Descriptor.getMetaList().then(data => {
        res.send(data)
        res.end()
    })
})

router.get('/getDescriptorById', (req, res) => {
    console.log('GET::/getDescriptorById')
    Descriptor.getById(req.query.id).then(data => {
        res.send(data)
        res.end()
    })
})

module.exports = router;