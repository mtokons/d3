/**
 * 
 * @author len_wei
 * @version 20180705
 */
const express = require('express')
const router = express.Router()

const appRoot = require('app-root-path');
const DB = require(appRoot + '/server/db/dummyDB.js');

router.get('/getTasks', function (req, res) {
    console.log('GET::/getTasks')
    res.send(DB.getTasks())
    res.end()
})

router.post('/addTask', function (req, res) {
    console.log('POST::/addTask')
    res.send(DB.addTask(req.body))
    res.end()
})

router.delete('/deleteTask', function (req, res) {
    console.log('DELETE::/deleteTask')
    res.send(DB.deleteTask(req.query.id))
    res.end()
})

router.put('/updateTask', function (req, res) {
    console.log('PUT::/updateTask')
    res.send(DB.updateTask(req.body))
    res.end()
})

module.exports = router;