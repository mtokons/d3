'use strict';

const fs = require('fs')
const appRoot = require('app-root-path')
const winston = require(appRoot + '/server/logger/logger.js')

const mongoose = require('mongoose')
mongoose.Promise = global.Promise

const dbConns = {};

var dbSettings = {};

/**
 * 
 * @version 20171107
 */
module.exports = function () {
  let dbName
  let connString

  if (arguments.length === 1) {
    dbName = arguments[0]
  } else {
    winston.log('err', 'db_config create db connection error')
    throw new Error('\x1b[31m db_config create db connection error \x1b[0m')
  }

  const configPath = '/server/config/config.json';

  const contents = fs.readFileSync(appRoot + configPath, 'utf8');
  if (contents) {
    const config = JSON.parse(contents);
    // winston.log('debug', 'config: %s', JSON.stringify(config))
    if (dbName == 'data_db') {
      dbSettings = {
        username: 'ro_user', // read only user
        password: 'ju7Wuj6Aep3y3',
        host: config.host,
        port: 27017,
        dbName: 'data_db',
        authDbName: 'admin'
      }
    }

    // Chech if the db connection already exists
    if (dbConns[dbName] === undefined) {

      connString = 'mongodb://' +
        dbSettings.username + ':' +
        dbSettings.password + '@' +
        dbSettings.host + ':' +
        dbSettings.port + '/' +
        dbSettings.dbName + '?authSource=' +
        dbSettings.authDbName;

      // create connection and add it to the list of the connections
      if (connString !== undefined) {
        let outputstring = dbSettings.host + ':' + dbSettings.port + '/' + dbSettings.dbName;
        dbConns[dbName] = mongoose.createConnection(connString, (err, res) => {
          if (err) {
            winston.log('error', 'Connecting to: %s', outputstring)
          } else {
            winston.log('info', 'Successfully connected to: %s', outputstring)
          }
        })
        return dbConns[dbName]
      } else {
        winston.log('error', 'db connection params undefiend')
        throw new Error('\x1b[31m db connection params undefiend \x1b[0m')
      }
    } else {
      // Return existing connections
      return dbConns[dbName]
    }
  } else {
    winston.log('debug', 'Cant open config file: %s', configPath)
  }

}