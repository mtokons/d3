'use strict';

var appRoot = require('app-root-path');

var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var fieldBasics = require(appRoot + '/server/db/data/descriptor/fieldBasics.js');
var hashid = require(appRoot + '/server/db/data/hashids.js');
var winston = require(appRoot + '/server/logger/logger.js');

/**
 * Makes sure that if this file is to be parsed,
 * the parser id is set
 */
var assertId = function() {
  return !this.parser || (this.parser && !isNaN(this.parserId));
};

/**
 * Accept either UTF-8 or ISO-8859-1
 */
var verifyEncoding = function() {
  return this.encoding === 'utf8' || this.encoding === 'latin1';
};

/**
 * @class sampleSchema
 */
var uploadSchema = new Schema({
  fieldBasics : fieldBasics,
  filetype : { type: String },
  multiple : { type: Boolean, default: false },
  parse : { type: Boolean, default: false, validate: assertId },
  encoding : { type: String, default: 'utf8', validate: verifyEncoding },
  uploadId : { type: Number }
}, { usePushEach : true });

uploadSchema.virtual('hashedId').get(function() {
  var hash = hashid.encodeHex(this._id);
  winston.log('debug', 'Hashing %s to %s', this._id, hash);
  return hash;
});

module.exports = uploadSchema;
