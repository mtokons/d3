'use strict';

var appRoot = require('app-root-path');

var mongoose = require('mongoose');
var Schema = mongoose.Schema;
var hashid = require(appRoot + '/server/db/data/hashids.js');
var winston = require(appRoot + '/server/logger/logger.js');
var fieldBasics = require(appRoot + '/server/db/data/descriptor/fieldBasics.js');

/**
 * @class sampleSchema
 */
var sampleSchema = new Schema({

  fieldBasics : fieldBasics,

  /**
   * A suggestion of which sample ID to put in this
   * fields. Default value should be replaced with
   * a specific example
   *
   * @property placeholder 
   */
  placeholder : { type : String, default : 'z.B. U01.1.1.1'},

  /**
   * Indicates that when displaying the input form,
   * the user shall have the option to put in a range
   * of sampleIds (referring to the sample segment)
   * of the entire sampleId
   *
   * @property rangeForSample
   */
  rangeForSample : { type : Boolean, default : false },

  /**
   * Indicates that when displaying the input form,
   * the user shall have the option to put in a range
   * of sampleIds (referring to the sample segment)
   * of the entire sampleId
   *
   * @property rangeForSample
   */
  maxRange : { type : Number, default : 100 },

  /**
   * A referencing sample is not the one that this input
   * form seeks to create/manipulate, but a sample that
   * was used whilst performing the measurement/creation.
   * Example: Material is molden and reused to create a
   * new sample
   *
   * @property referencingSample
   */
  referencingSample : { type : Boolean, default : false },

  /**
   * Indicates, if the user is allowed to put in multiple
   * individual samples (or ranges)
   *
   * @property multipleSamples
   */
  multipleSamples : { type : Boolean, default : false },

  /**
   * Defines a prefix that the user inputs starts with.
   * Useful for primary shaping inputs forms
   *
   * @property prefix
   */
  prefix : { type : String, default : '' },

  /**
   * If this sample has {{#crossLink "sampleSchema/referencingSample:property"}}{{/crossLink}}
   * set to true, this field will define to what "extend" the sample(s) are referenced.
   *
   * This is a workaround until there is a user input to specify this amount in the input form.
   *
   * Until then, it is suggested to either not use it or set it to 100.
   *
   * @property percentage
   */
  percentage : { type : Number, max : 100 },

  /**
   * If this attribute is set, then the corresponding input
   * form must create an individual sample from a sample template
   * on the fly
   *
   * @property mustCreateFromtemplate
   */
  mustCreateFromTemplate : { type: Boolean, default: false },

  /**
   * Usually, users are required to put in a fully qualified
   * sampleId, that is, a sampleId like 'U01.1.1.1', where the
   * last segment refers to the individual sample.
   *
   * This property allows the user input form to refer to 'higher'
   * or 'lower' segments of the sampleId object while at the same
   * time enforcing a sampleId of that very pattern.
   *
   * Example: -1 on a project with a subcharge (U01) means,
   * the user refers to 'U01.1.1', which is a subsample
   *
   * @property enforcedSegmentDeviation
   */
  enforcedSegmentDeviation : {
    type : Number,
    default : 0,
    min : -2,
    max : 2
  }
}, { usePushEach : true });

sampleSchema.pre('validate', function(next) {
  let invalid =
    this.rangeForSample &&
    this.deviation !== undefined && 
    this.deviation !== 0;
  if (invalid) {
    return next(new Error('Deviation and rangeForSample are mutually exclusive'));
  }
  return next();
});

sampleSchema.virtual('hashedId').get(function() {
  var hash = hashid.encodeHex(this._id);
  winston.log('debug', 'Hashing %s to %s', this._id, hash);
  return hash;
});

module.exports = sampleSchema;
