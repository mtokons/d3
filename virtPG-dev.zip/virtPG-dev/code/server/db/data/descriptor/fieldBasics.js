'use strict';

var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var sanitizeString = function(string) {
  return string.split(' ').join('_');
};

var fieldBasics = new Schema({
  _id: false, // no need to let db assign id
  id: Number, // needs to be unique within document only
  required : { type: Boolean, default: false },
  fieldname: String,
  tooltip_append : String,
  mutex: [Number]
}, { usePushEach : true });

fieldBasics.virtual('sanitizedName').get(function() {
  return sanitizeString(this.fieldname);
});

module.exports = fieldBasics;