'use strict';

var appRoot = require('app-root-path');

var winston = require(appRoot + '/server/logger/logger.js');
var mongoose = require('mongoose');
var Schema = mongoose.Schema;
var katex = require('katex');
var fieldBasics = require(appRoot + '/server/db/data/descriptor/fieldBasics.js');

var freetextSchema = new Schema({
  fieldBasics: fieldBasics,
  placeholder: String,
  // Symbol for this field in latex
  symbol_latex: { type: String },
  // Fallback for latex compiler errors
  symbol_plain: String,
  unit_latex: String,
  unit_plain: String,
  inputLimits : [{
    type : String,
    enum : ["int", "uint", "float", "ufloat", "interval", "tuple"]
  }],
  upperBound : Number,
  lowerBound : Number
}, { usePushEach : true });

freetextSchema.virtual('unit').get(function() {
  var unit;
  try {
    unit = katex.renderToString(this.unit_latex);
  } catch (err) {
    winston.log('err', "Error parsing latex: %s", err);
    unit = this.unit_plain;
  } finally {
    return unit;
  }
});

freetextSchema.virtual('symbol').get(function() {
  var symbol;
  let katexOpts = { strict: false };
  try {
    symbol = katex.renderToString(this.symbol_latex, katexOpts);
  } catch (err) {
    winston.log('err', "Error parsing latex: %s", err);
    symbol = this.symbol_plain;
  } finally {
    return symbol;
  }
});

/*
 * Make sure both or none unit fields are set
 */
freetextSchema.pre('validate', function(next) {
  if (!this.unit_plain !== !this.unit_latex) {
    return next(new Error("When units are used in freetext fields,\
      both latex and plain text have to be given"));
  }
  if (!this.symbol_plain !== !this.symbol_latex) {
    return next(new Error("When symbols are used in freetext fields,\
      both latex and plain text have to be given"));
  }
  next();
});


module.exports = freetextSchema;
