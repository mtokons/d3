'use strict';

var appRoot = require('app-root-path');

var winston = require(appRoot + '/server/logger/logger.js');
var mongoose = require('mongoose');
var Schema = mongoose.Schema;
var db = require(appRoot + '/server/db/config.js')('data_db');
var fieldBasics = require(appRoot + '/server/db/data/descriptor/fieldBasics.js');
var freetextSchema = require(appRoot + '/server/db/data/descriptor/freetext.js');
var sampleSchema = require(appRoot + '/server/db/data/descriptor/sample.js');
var uploadSchema = require(appRoot + '/server/db/data/descriptor/upload.js');
var hashid = require(appRoot + '/server/db/data/hashids.js');
var async = require('asyncawait/async');
var await = require('asyncawait/await');
var util = require('util');
var Promise = require('bluebird');

var hashMap;
var nameMap;

var metadata = new Schema({
  sample : [ sampleSchema ],
  freetext: [freetextSchema],
  // Only one option can be chosen
  chooseOne: [{
    fieldBasics: fieldBasics,
    options: [fieldBasics]
  }],
  // N options can be chosen
  chooseN: [{
    fieldBasics: fieldBasics,
    options: [fieldBasics]
  }],
  checkbox : [fieldBasics],
  periodicTable : [{
    fieldBasics : fieldBasics,
    freetext : freetextSchema
  }]
}, { usePushEach : true });

var descriptorSchema = new Schema({
  project: { type: String, required: true },
  // Project internal enumeration. Not subject to change!
  number: { type: Number, required: true },
  name: { type: String, required: true },
  // Type of definition/data
  // Abbreviation
  clazz: { type: String, required: true },
  // Indicates that this form is used to create a
  // new sample. 'usessubcharge' tells other forms
  // in which segment of the sample description the
  // individual sample is stored. Compare (S02.1.1 vs.
  // U01.1.1.1), where in index 2 and index 3
  // respectively define the individual sample
  primeShaping : { 
    usesSubcharge: Boolean,
    splitsSample: Boolean
  },
  prodReady : { type: Boolean, default: false },
  isModifying: { type: Boolean, default: false },
  isDescriptor : { type: Boolean, default: false },
  sampleAdmin : { type: Boolean, default: false },
  destroysSample : { type: Boolean, default: false },
  prefillDate : { type: Boolean, default: false },
  short: { type: String },
  technicianRequired : { type: Boolean, default: true },
  uploads: [ uploadSchema ],
  // Revision of this schema. Must be incremented by 1 at a time.
  revision: { type: Number, required: true },
  // Indicates if this revision is the latest one found.
  // Generated automatically.
  current: { type: Boolean },
  // Reason for change in the current revision ("commit message")
  message: { type: String, required: true },
  // Persistent meta information is likely to remain stable
  // across multiple uploads.
  persistentMeta: [{
    fieldBasics : fieldBasics,
    data : metadata
  }],
  // Volatile meta inforamtion fields are cleared after upload
  volatileMeta: [{
    fieldBasics : fieldBasics,
    duplicatable : Boolean,
    data : metadata
  }]
}, {
  toObject : {
    virtuals : true
  }
}, { usePushEach : true });

// Use this instead of manual check in code. Leave commented
// for now
descriptorSchema.virtual('isPrimeShaping').get(function() {
  return this.primeShaping.usesSubcharge !== undefined ||
    this.primeShaping.splitsSample !== undefined;
});

descriptorSchema.virtual('readyForProd').get(function() {
  return showNotReady || this.prodReady;
});

descriptorSchema.virtual('humanId').get(function() {
  return [ this.project, this.number ].join('.');
});

descriptorSchema.methods.getPersistentFieldnames = function() {

  let persistentMeta = this.persistentMeta;

  if (persistentMeta === undefined) {
    return [];
  }

  let block, input, key, data, inputType, elem;
  let persistentFieldnames = [];

  for (block in persistentMeta) {
    if (persistentMeta.hasOwnProperty(block)) {
      data = persistentMeta[block].data;
      for (key in data) {
        if (data.hasOwnProperty(key)) {
          inputType = data[key];
          for (input in inputType) {
            if (inputType.hasOwnProperty(input)) {
              elem = inputType[input];
              if (typeof elem !== 'undefined' && typeof elem.fieldBasics !== 'undefined') {
                persistentFieldnames.push(elem.fieldBasics.fieldname);
              }
            }
          }
        }
      }
    }
  }

  return persistentFieldnames;
};

var Descriptor = db.model('Descriptor', descriptorSchema);


Descriptor.getById = function (id) {
  return Promise.resolve().then(() => {
    return Descriptor.aggregate(
      // Pipeline
      [
        // Stage 1
        {
          $match: {
            _id: mongoose.Types.ObjectId(id)
          }
        },
        // Stage2
        {
          $project: {
            _id: 1,
            name: 1,
            project: 1,
            primeShaping: 1,
            volatileMeta: 1,
            persistentMeta: 1,
          }
        }
      ]
    ).exec()
      .then((res) => {
        if (res) {
          return res
        } else {
          throw new Error('Could not find Descriptor')
        }
      })
  })
}

Descriptor.getMetaList = () => {
  return Promise.resolve().then(() => {
    return Descriptor.aggregate(
      // Pipeline
      [

        // Stage 0
        {
          $match: {
            current: true,
          }
        },

        // Stage 1
        {
          $project: {
            _id: 1,
            name: 1,
            project: 1,
          }
        },

        // Stage 2
        {
          $sort: {
            project: 1,
            name: 1
          }
        }
      ]
    ).exec()
      .then((res) => {
        if (res) {
          return res
        } else {
          throw new Error('Could not find Descriptor')
        }
      })
  })
}

module.exports = Descriptor;