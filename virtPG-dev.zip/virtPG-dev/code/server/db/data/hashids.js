'use strict';

var Hashids = require('hashids');
var hashid = new Hashids();

module.exports = hashid;