
module.exports = {
 
    getTasks: () => {
        console.log('DummyDB::getTasks'+'\n')
        let list = [];
        list.push({ _id: 0, category: 'maths', description: 'exercise 1'});
        list.push({ _id: 1, category: 'english', description: 'exercise 2b'});
        list.push({ _id: 2, category: 'physics', description: 'experiment 7'});
        list.push({ _id: 3, category: 'sport', description: 'run 5 miles'});
        return list;
    },

    addTask: (task) =>{
        console.log('DummyDB::addTask')
        console.log(JSON.stringify(task, null, 2)+'\n')
        return true;
    },

    updateTask: (task) =>{
        console.log('DummyDB::updateTask')
        console.log(JSON.stringify(task, null, 2)+'\n')
        return true;
    },

    deleteTask: (task) =>{
        console.log('DummyDB::deleteTask')
        console.log(JSON.stringify(task, null, 2)+'\n')
        return true;
    }
};