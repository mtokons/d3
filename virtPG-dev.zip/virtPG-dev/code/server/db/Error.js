'use strict';

// See https://gist.github.com/justmoon/15511f92e5216fa2624b
// for idea

module.exports = {

  UserInputError: function(message, extra) {
    Error.captureStackTrace(this, this.constructor);
    this.name = this.constructor.name;
    this.message = message;
    this.extra = extra;
  },

  ParseError: function(message, extra) {
    Error.captureStackTrace(this, this.constructor);
    this.name = this.constructor.name;
    this.message = message;
    this.extra = extra;
  },

  ConfigError: function(message, extra) {
    Error.captureStackTrace(this, this.constructor);
    this.name = this.constructor.name;
    this.message = message;
    this.extra = extra;
  },

  SampleError: function(message, extra) {
    Error.captureStackTrace(this, this.constructor);
    this.name = this.constructor.name;
    this.message = message;
    this.extra = extra;
  }
};

require('util').inherits(module.exports.ParseError, Error);
require('util').inherits(module.exports.UserInputError, Error);
require('util').inherits(module.exports.ConfigError, Error);
require('util').inherits(module.exports.SampleError, Error);
