const winston = require('winston')
const appRoot = require('app-root-path')
winston.emitErrs = true

const logger = new winston.Logger({
    transports: [
        new winston.transports.File({
            level: 'info',
            filename: appRoot +'/server/logs/info.log',
            handleExceptions: true,
            json: true,
            maxsize: 5242880, //5MB
            maxFiles: 5,
            colorize: true
        }),
        new winston.transports.Console({
            level: 'debug',
            filename: appRoot +'/server/logs/debug.log',
            handleExceptions: true,
            json: false,
            colorize: true
        }),
    ],
    exitOnError: false
})

module.exports = logger
module.exports.stream = {
    write: (message, encoding) => {
        logger.info(message)
    }
}
