import { Component, OnInit } from '@angular/core';

import { MongoService } from '../../services/mongo.service';

@Component({
  selector: 'app-mondo',
  templateUrl: './mondo.component.html',
  styleUrls: ['./mondo.component.css'],
  providers: [MongoService]
})
export class MondoComponent implements OnInit {

  descriptor_list;
  descriptor_in_detail;
  hasEntry: boolean = false;

  constructor(private mongo: MongoService) { }

  ngOnInit() {
    this.mongo.getDescriptorList().subscribe(data => {
      this.descriptor_list = data
    })
  }

  print(list): string {
    return JSON.stringify(list, null, 2);
  }

  loadDetails(id) {
    this.mongo.getDescriptor(id).subscribe(data => {
      this.descriptor_in_detail = data;
      this.hasEntry = true;
    })
  }
}
