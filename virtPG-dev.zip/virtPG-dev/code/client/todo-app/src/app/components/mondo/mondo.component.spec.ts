import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { HttpClientModule } from '@angular/common/http';

import { MondoComponent } from './mondo.component';
import { MatExpansionModule } from '@angular/material/expansion';

// import { MongoService } from '../../services/mongo.service';

describe('MondoComponent', () => {
  let component: MondoComponent;
  let fixture: ComponentFixture<MondoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        MatExpansionModule,
        HttpClientModule,
        BrowserAnimationsModule
      ],
      declarations: [ MondoComponent ],
      providers: [
        HttpClientModule
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MondoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
