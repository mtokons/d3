import { Component, OnInit } from '@angular/core';

import { Task } from '../../model/task';
import { TodoService } from '../../services/todo.service';

@Component({
  selector: 'app-administration',
  templateUrl: './administration.component.html',
  styleUrls: ['./administration.component.css'],
  providers: [TodoService]
})
export class AdministrationComponent implements OnInit {

  constructor(private todoService: TodoService) { }

  tasks: Task[] = [];

  isVisible_Tasks: boolean = true;
  isVisible_AddTask: boolean = false;
  isVisible_DeleteTask: boolean = false;
  isVisible_UpdateTask: boolean = false;

  new_Task_id: number = -1;
  new_Task_category: string = '';
  new_Task_description: string = '';

  delete_Task_Id: number = -1;

  update_Task_id: number = -1;
  update_Task_category: string = '';
  update_Task_description: string = '';

  ngOnInit() {
    this.todoService.getTasks().subscribe((data: Task[]) => {
      this.tasks = data;
      let last = this.tasks[this.tasks.length - 1];
      this.new_Task_id = last._id + 1;
    })
  }

  addTask() {
    console.log('Add Task')
    const t = new Task(this.new_Task_id, this.new_Task_description, this.new_Task_category);
    this.todoService.addTask(t).subscribe(
      res => {
        console.log(res)
        this.new_Task_id++;
        this.tasks.push(t);
      },
      err => { console.error(err) }
    )
  }

  clearAddTaskForm() {
    this.new_Task_category = '';
    this.new_Task_description = '';
  }

  deleteTask() {
    console.log('Delete Task')
    let index = this.tasks.findIndex(item => item._id == this.delete_Task_Id)
    if (index > -1) {
      this.todoService.deleteTask(this.delete_Task_Id).subscribe(res => {
        console.log(res)
        // remove the task with the id = delete_Task_Id
        this.tasks.splice(index, 1);
        // update the id for the new task form
        let last = this.tasks[this.tasks.length - 1];
        this.new_Task_id = last._id + 1;
      }, err => {
        console.log(err)
      })
    }
  }

  clearDeleteTaskForm() {
    this.delete_Task_Id = -1;
  }

  updateTask() {
    console.log('Update Task')
    const t = new Task(this.update_Task_id, this.update_Task_category, this.update_Task_description);
    this.todoService.updateTask(t).subscribe(res => {
      console.log(res)
      for (let i in this.tasks) {
        if (this.tasks[i]._id == this.update_Task_id) {
          this.tasks[i].category = this.update_Task_category;
          this.tasks[i].description = this.update_Task_description;
        }
      }
    }, err => {
      console.log(err)
    })
  }

  clearUpdateTaskForm() {
    this.update_Task_id = -1;
    this.update_Task_category = '';
    this.update_Task_description = '';
  }

  updateUpdateForm() {
    // check if the id exists
    let index = this.tasks.findIndex(item => item._id == this.update_Task_id)
    if (index > -1) {
      this.update_Task_category = this.tasks[this.update_Task_id].category;
      this.update_Task_description = this.tasks[this.update_Task_id].description;
    } else {
      this.update_Task_category = '';
      this.update_Task_description = '';
    }
  }

}
