import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { FormsModule } from '@angular/forms';
import { MatInputModule } from '@angular/material/input';
import { MatCardModule } from '@angular/material/card';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatListModule } from '@angular/material/list';
import { HttpClientModule } from '@angular/common/http';
import { MatExpansionModule } from '@angular/material/expansion';

import { AppComponent } from './app.component';
import { StartpageComponent } from './components/startpage/startpage.component';
import { AdministrationComponent } from './components/administration/administration.component';
import { MondoComponent } from './components/mondo/mondo.component';
import { ContactsComponent } from './components/contacts/contacts.component';

import { RouterModule, Routes } from '@angular/router';
const developmentRoutes: Routes = [
  { path: '', component: StartpageComponent },
  { path: 'administration', component: AdministrationComponent },
  { path: 'mongo', component: MondoComponent },
  { path: 'contacts', component: ContactsComponent },
];

@NgModule({
  declarations: [
    AppComponent,
    StartpageComponent,
    ContactsComponent,
    AdministrationComponent,
    MondoComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    BrowserAnimationsModule,
    MatToolbarModule,
    MatButtonModule,
    MatCheckboxModule,
    MatCardModule,
    MatSidenavModule,
    MatListModule,
    FormsModule,
    MatInputModule,
    MatExpansionModule,
    RouterModule.forRoot(developmentRoutes, { useHash: true }),
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
