import { TestBed, inject } from '@angular/core/testing';

import { MongoService } from './mongo.service';
import { HttpClientModule } from '@angular/common/http';

describe('MongoService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientModule],
      providers: [MongoService, HttpClientModule]
    });
  });

  it('should be created', inject([MongoService], (service: MongoService) => {
    expect(service).toBeTruthy();
  }));
});
