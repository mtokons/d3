import { Injectable } from '@angular/core';

import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import 'rxjs/Rx';

@Injectable()
export class MongoService {

  httpOptions = {
    headers: new HttpHeaders()
  };

  constructor(private http: HttpClient) { }

  getDescriptorList() {
    return this.http.get('/mongo/getDescriptorList');
  }

  getDescriptor(id) {
    const params = new HttpParams()
      .set('id', id + '')
    return this.http.get('/mongo/getDescriptorById', { params: params, headers: new HttpHeaders() });
  }
}
