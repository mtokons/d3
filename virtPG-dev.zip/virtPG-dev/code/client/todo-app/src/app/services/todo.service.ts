import { Injectable } from '@angular/core';

//import { Headers, Http, Response, RequestOptions } from '@angular/http'
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import 'rxjs/Rx';

import { Task } from '../model/task';

@Injectable()
export class TodoService {

  //header = new Headers({ 'Content-Type': 'application/json' });
  httpOptions = {
    headers: new HttpHeaders()
  };

  constructor(private http: HttpClient) { }

  getTasks() {
    return this.http.get('/api/getTasks');
  }

  addTask(task: Task) {
    return this.http.post<Task>('/api/addTask', task, this.httpOptions);
  }

  deleteTask(id: number) {
    const params = new HttpParams()
      .set('id', id + '')
    return this.http.delete('/api/deleteTask/', { params: params, headers: new HttpHeaders() });
  }

  updateTask(task: Task) {
    return this.http.put('/api/updateTask', task, this.httpOptions)
  }

}
