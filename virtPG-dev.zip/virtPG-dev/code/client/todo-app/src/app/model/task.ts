export class Task {
    _id: number;
    category: string;
    description: string;

    constructor(id, description, category = '') {
        this._id = id;
        this.description = description;
        this.category = category;
    }
}